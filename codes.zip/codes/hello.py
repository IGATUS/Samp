import streamlit as st
st.title('Streamlit Tutorials')
#heading
st.header('This is a header')
#subheading
st.subheader('this is a subheader')
st.text('hello streamlit')
st.markdown('this is a markdown')
#colorful text
st.success('successful')
st.warning('Are you ok')
st.info('information')
st.error('this is an error')
st.exception('NameError: name is not defined')
#getting help for any python function
st.help(range)
from PIL import Image
img=Image.open('product.png')
st.image(img,size=300,caption='flower product')
vid_file=open('comedy.mp4','rb').read()
st.video(vid_file)
if st.checkbox('show/hide'):
	st.text('showing or hiding')
#radio buttons
status=st.radio('what is your status?',('Active','Inactive'))
if status=='Active':
	st.success('You are active')
else:
	st.warning('You are Inactive')
#selectbox
occupation=st.selectbox('what is your occupation',['Programmer','data scientist','business man'])
st.write('You selected ',occupation)
location=st.multiselect('what is your location',('Accra','lagos','abuja','lokoja'))
st.write('You selected '+str(len(location))+' locations')
#slider
age=st.slider('what is your age',18,35)
#buttons
st.button('simple buttons')
if st.button('About'):
	st.text('streamlit is cool')
#working with text
name=st.text_input('Enter your Firstname','Type Here......')
if st.button('Submit'):
	result=name.title()
	st.success(result)
#Text area
message=st.text_area('Enter your message','Type Here......')
if st.button('Ok'):
	result=message.title()
	st.success(result)
#date
import datetime
today=st.date_input('Today is',datetime.datetime.now())
the_time=st.time_input('the time is ',datetime.time())
#displaying code
st.code('import pandas as pd')
with st.echo():
	#this will also show
	import pandas as pd
	pd.DataFrame()
#progress bar
import time
my_bar=st.progress(0)
for p in range(10):
	my_bar.progress(p+1)
#spinners
with st.spinner('Waiting....'):
	time.sleep(5)
st.success('Finished')

st.balloons()
#sidebar
st.sidebar.header('About')
st.sidebar.text('this is streamlit tut')
